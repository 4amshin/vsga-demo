<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>
    <!--Title-->
    <h1 class="auth-title">VSGA-DEMO</h1>
    <p class="auth-subtitle mb-5"></p>

    <!--Form-->
    <form action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <!--Email-->
        <div class="form-group position-relative has-icon-left mb-4">
            <!--Input-->
            <input type="text" name="email" class="form-control form-control-xl <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                placeholder="Email">

            <!--Icon-->
            <div class="form-control-icon">
                <i class="bi bi-envelope"></i>
            </div>

            <!--Pesan Eror-->
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!--Password-->
        <div class="form-group position-relative has-icon-left mb-4">
            <!--Input-->
            <input type="password" name="password"
                class="form-control form-control-xl <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password">

            <!--Icon-->
            <div class="form-control-icon">
                <i class="bi bi-shield-lock"></i>
            </div>

            <!--Pesan Eror-->
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!--Tombol Login-->
        <button type="submit" class="btn btn-primary btn-block btn-lg shadow-lg mt-5">Log in</button>
    </form>

    <!--Link Lupa Password-->
    <div class="text-center mt-5 text-lg fs-4">
        <p>
            <a class="font-bold" href="<?php echo e(route('password.request')); ?>">Lupa Password?</a>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('customJs'); ?>
    <script src="<?php echo e(asset('assets/custom.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vsga-demo\resources\views/auth/login.blade.php ENDPATH**/ ?>