<div class="auth-logo">
    <a href="index.html"><img src="<?php echo e(asset('assets/compiled/svg/logo.svg')); ?>" alt="Logo"></a>
</div>
<?php /**PATH C:\laragon\www\vsga-demo\resources\views/layout/logo.blade.php ENDPATH**/ ?>