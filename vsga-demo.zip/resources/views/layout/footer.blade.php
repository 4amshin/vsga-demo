<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2024 &copy; Sipandu</p>
        </div>
    </div>
</footer>
